# ICDE 2027 review artifact

This is the minimal artifact for **High-Level Rule Editing in LLMs with Incomplete Downstream Coverage**. It contains the frozen v1.1 executable-rule dataset, the core construction/training/scoring scripts, the 13 reported systems' test answers (eight main systems and five component ablations), and their frozen v0.6 item-level judgments. Earlier pilots, local paths, API credentials, raw request logs, and model checkpoints are excluded.

## Contents

- `data/`: rule and domain specifications, split manifest, case facts, executable gold states, prompts, calibration cases, and validation report.
- `code/`: scripts used to construct data, train/update models, run inference, and score responses. Model weights are obtained separately from the relevant model providers; training adapters are not included in this compact review package.
- `predictions/`: test answers with only IDs, case metadata, method name, and answer text. Provider request IDs and execution metadata have been removed.
- `scores/item_scores.csv`: the frozen eight-field judgments for every reported answer. `strict_status` is the frozen overall judgment. `formal_guard_error_count` records explicit guard findings.
- `manifest.json`: counts and SHA-256 checksums of packaged source files.

The dataset uses 2,420 semantic case families (540 train, 180 development, 1,700 held-out-domain test), each with three phrasings. Gold states come from executable rules rather than a language model.

## Recompute reported metrics

Run `python recompute_metrics.py` from any directory. The script prints strict complete-answer correctness, final-decision accuracy, the decision-gated score, and the uncertain rate for each of the eight main systems and five ablations. Every method has 5,100 test answers. The three phrasings of one family share a family ID; bootstrap confidence intervals in the paper are clustered by that ID.

The CSV retains the frozen field consensus used for the paper's headline scores. The full prompt-level reader evidence and raw API transport logs are outside this compact package. All cases are synthetic and set in controlled fictional environments.
